
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="text-center py-8 md:py-12">
      <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-600">
        AI Blog Post Agent
      </h1>
      <p className="mt-4 text-lg text-text-secondary max-w-2xl mx-auto">
        Enter a topic and our AI, powered by Gemini and grounded in news from BBC and Wion, will craft a high-quality blog post for you.
      </p>
    </header>
  );
};

export default Header;
