import React, { useState } from 'react';
import { BlogPost } from '../types';

interface BlogPostDisplayProps {
  blogPost: BlogPost;
}

// --- ICONS ---

const ThumbsUpIcon: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.085a2 2 0 00-1.736.97l-2.714 4.224a2 2 0 01-1.453 1.055H5.5A2.5 2.5 0 003 12.5v5a2.5 2.5 0 002.5 2.5h2.986" />
  </svg>
);

const ThumbsDownIcon: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M10 14H5.236a2 2 0 01-1.789-2.894l3.5-7A2 2 0 018.738 3h4.017c.163 0 .326.02.485.06L17 4m-7 10v5a2 2 0 002 2h.085a2 2 0 001.736-.97l2.714-4.224a2 2 0 011.453-1.055H18.5a2.5 2.5 0 002.5-2.5v-5a2.5 2.5 0 00-2.5-2.5h-2.986" />
  </svg>
);

const TwitterIcon: React.FC = () => (
  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
    <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.71v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
  </svg>
);

const LinkedInIcon: React.FC = () => (
    <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
    </svg>
);

const FacebookIcon: React.FC = () => (
    <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
        <path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z" />
    </svg>
);

const TECH_KEYWORDS = ['GPU', 'CPU', 'processor', 'chip', 'semiconductor', 'AI accelerator', 'NPU', 'TPU', 'quantum', 'silicon', 'RISC-V', 'ARM', 'NVIDIA', 'AMD', 'Intel', 'motherboard', 'RAM', 'SSD', 'ray tracing', 'neural engine'];

const highlightText = (text: string) => {
  if (!text) return '';
  const regex = new RegExp(`\\b(${TECH_KEYWORDS.join('|')})\\b`, 'gi');
  const parts = text.split(regex);
  return (
    <>
      {parts.map((part, i) =>
        TECH_KEYWORDS.some(keyword => new RegExp(`^${keyword}$`, 'i').test(part)) ? (
          <span key={i} className="text-cyan-400 font-semibold">{part}</span>
        ) : (
          part
        )
      )}
    </>
  );
};


const BlogPostDisplay: React.FC<BlogPostDisplayProps> = ({ blogPost }) => {
  const [feedback, setFeedback] = useState<'like' | 'dislike' | null>(null);

  const handleFeedback = (type: 'like' | 'dislike') => {
    setFeedback(type);
    console.log(`User feedback for the post: ${type}`);
  };
  
  const getTitle = (content: string) => {
    const lines = content.split('\n');
    const titleLine = lines.find(line => line.startsWith('# '));
    return titleLine ? titleLine.substring(2) : 'Check out this AI-generated blog post';
  };

  const blogTitle = getTitle(blogPost.content);

  const handleShare = (platform: 'twitter' | 'linkedin' | 'facebook') => {
    const shareUrl = window.location.href;
    let url = '';
    const encodedTitle = encodeURIComponent(blogTitle);
    const encodedUrl = encodeURIComponent(shareUrl);

    switch(platform) {
        case 'twitter':
            url = `https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encodedUrl}`;
            break;
        case 'linkedin':
            url = `https://www.linkedin.com/shareArticle?mini=true&url=${encodedUrl}&title=${encodedTitle}`;
            break;
        case 'facebook':
            url = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`;
            break;
    }
    window.open(url, '_blank', 'noopener,noreferrer');
  }

  const renderContent = (content: string) => {
    const elements: React.ReactNode[] = [];
    const lines = content.split('\n');
    let i = 0;
    while (i < lines.length) {
      const line = lines[i].trim();

      if (line.startsWith('# ')) {
        elements.push(<h1 key={i} className="text-4xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-600">{line.substring(2)}</h1>);
        i++;
      } else if (line.startsWith('## ')) {
        elements.push(<h2 key={i} className="text-2xl font-bold mt-6 mb-3 text-text-main">{line.substring(3)}</h2>);
        i++;
      } else if (line.startsWith('* ') || line.startsWith('- ')) {
        const listItems = [];
        while (i < lines.length && (lines[i].trim().startsWith('* ') || lines[i].trim().startsWith('- '))) {
          listItems.push(<li key={i} className="my-2 text-lg text-text-secondary leading-relaxed">{highlightText(lines[i].trim().substring(2))}</li>);
          i++;
        }
        elements.push(<ul key={`ul-${i}`} className="list-disc list-inside space-y-2 pl-4">{listItems}</ul>);
      } else if (/^\d+\.\s/.test(line)) {
        const listItems = [];
        while (i < lines.length && /^\d+\.\s/.test(lines[i].trim())) {
           listItems.push(<li key={i} className="my-2 text-lg text-text-secondary leading-relaxed">{highlightText(lines[i].trim().substring(lines[i].trim().indexOf(' ') + 1))}</li>);
           i++;
        }
        elements.push(<ol key={`ol-${i}`} className="list-decimal list-inside space-y-2 pl-4">{listItems}</ol>);
      } else if (line.startsWith('**') && line.endsWith('**')) {
        elements.push(<p key={i} className="my-4 text-lg font-bold">{highlightText(line.substring(2, line.length - 2))}</p>);
        i++;
      } else if (line.length > 0) {
        elements.push(<p key={i} className="my-4 text-lg text-text-secondary leading-relaxed">{highlightText(line)}</p>);
        i++;
      } else {
        i++; // Skip empty lines
      }
    }
    return elements;
  };

  return (
    <div className="w-full max-w-4xl bg-surface p-6 sm:p-8 rounded-xl border border-border-color shadow-lg animate-fade-in">
      <article className="prose prose-invert prose-lg max-w-none">
        {renderContent(blogPost.content)}
      </article>

      {/* Feedback Section */}
      <div className="mt-12 border-t border-border-color pt-6">
        {!feedback ? (
          <>
            <h3 className="text-xl font-semibold text-text-main mb-4">Was this article helpful?</h3>
            <div className="flex items-center gap-4">
              <button
                onClick={() => handleFeedback('like')}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-transparent border border-green-500 text-green-400 hover:bg-green-500/20 transition-colors"
                aria-label="Like this post"
              >
                <ThumbsUpIcon />
                <span>Like</span>
              </button>
              <button
                onClick={() => handleFeedback('dislike')}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-transparent border border-red-500 text-red-400 hover:bg-red-500/20 transition-colors"
                aria-label="Dislike this post"
              >
                <ThumbsDownIcon />
                <span>Dislike</span>
              </button>
            </div>
          </>
        ) : (
          <p className="text-lg text-green-400 font-medium">Thanks for your feedback!</p>
        )}
      </div>

       {/* Share Section */}
      <div className="mt-8 border-t border-border-color pt-6">
        <h3 className="text-xl font-semibold text-text-main mb-4">Share this post</h3>
        <div className="flex items-center gap-4">
            <button onClick={() => handleShare('twitter')} aria-label="Share on Twitter" className="text-text-secondary hover:text-primary transition-colors"><TwitterIcon /></button>
            <button onClick={() => handleShare('linkedin')} aria-label="Share on LinkedIn" className="text-text-secondary hover:text-primary transition-colors"><LinkedInIcon /></button>
            <button onClick={() => handleShare('facebook')} aria-label="Share on Facebook" className="text-text-secondary hover:text-primary transition-colors"><FacebookIcon /></button>
        </div>
      </div>

      {blogPost.sources && blogPost.sources.length > 0 && (
        <div className="mt-8 border-t border-border-color pt-6">
          <h3 className="text-xl font-semibold text-text-main mb-4">Sources</h3>
          <ul className="space-y-2">
            {blogPost.sources.map((source, index) => (
              <li key={index} className="flex items-start">
                <span className="text-primary mr-2">●</span>
                <a
                  href={source.uri}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline break-all"
                >
                  {source.title}
                </a>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default BlogPostDisplay;
