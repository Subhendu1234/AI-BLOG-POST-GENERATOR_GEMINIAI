
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="w-full text-center py-6 mt-12 border-t border-border-color">
      <p className="text-text-secondary">
        Powered by Google Gemini.
      </p>
    </footer>
  );
};

export default Footer;
