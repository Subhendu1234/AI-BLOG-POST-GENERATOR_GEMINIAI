
import React from 'react';

interface SearchBarProps {
  topic: string;
  setTopic: (topic: string) => void;
  onGenerate: () => void;
  isLoading: boolean;
}

const SearchBar: React.FC<SearchBarProps> = ({ topic, setTopic, onGenerate, isLoading }) => {
  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter' && !isLoading) {
      onGenerate();
    }
  };

  return (
    <div className="flex flex-col sm:flex-row items-center gap-4 w-full max-w-2xl">
      <input
        type="text"
        value={topic}
        onChange={(e) => setTopic(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="e.g., 'The future of renewable energy in Europe'"
        className="w-full px-4 py-3 bg-surface border border-border-color rounded-lg focus:ring-2 focus:ring-primary focus:outline-none transition-shadow duration-200"
        disabled={isLoading}
      />
      <button
        onClick={onGenerate}
        disabled={isLoading || !topic}
        className="w-full sm:w-auto px-6 py-3 bg-primary text-white font-semibold rounded-lg shadow-md hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-brand-bg focus:ring-primary disabled:bg-gray-500 disabled:cursor-not-allowed transition-all duration-200"
      >
        {isLoading ? 'Generating...' : 'Generate'}
      </button>
    </div>
  );
};

export default SearchBar;
