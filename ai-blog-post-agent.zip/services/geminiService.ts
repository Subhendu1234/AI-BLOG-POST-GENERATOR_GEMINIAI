
import { GoogleGenAI } from "@google/genai";
import { BlogPost, Source } from '../types';

export async function generateBlogPost(topic: string): Promise<BlogPost | null> {
  // It's better to create a new instance each time in environments where API keys can change.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const prompt = `
    You are an expert blog post writer. Your task is to generate a comprehensive, well-structured, and easy-to-read blog post on the following topic: "${topic}".

    Your research must be based on the latest information from top news channels, specifically focusing on sources like BBC and Wion.

    The blog post must have the following structure:
    1.  **Catchy Title**: An engaging title for the blog post, starting with '# '.
    2.  **Introduction**: A brief overview of the topic, grabbing the reader's attention.
    3.  **Main Body**: Several sections with clear subheadings (using '## '). Each section should delve into a specific aspect of the topic.
    4.  **Conclusion**: A summary of the key points and a concluding thought, under a '## Conclusion' subheading.

    Maintain a professional and objective tone throughout the article. The final output must be in Markdown format.
    Ensure paragraphs are separated by a single newline.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const content = response.text;
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

    const sources: Source[] = groundingChunks
      .map((chunk: any) => ({
        uri: chunk.web?.uri || '',
        title: chunk.web?.title || 'Untitled Source',
      }))
      .filter((source: Source) => source.uri)
      // Deduplicate sources
      .filter((source, index, self) =>
        index === self.findIndex((s) => s.uri === source.uri)
      );

    return { content, sources };

  } catch (error) {
    console.error("Error generating blog post:", error);
    throw new Error("Failed to generate blog post. Please check the topic or try again later.");
  }
}
